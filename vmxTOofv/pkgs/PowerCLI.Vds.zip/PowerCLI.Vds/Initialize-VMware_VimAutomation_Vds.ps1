[VMware.VimAutomation.Sdk.Interop.V1.CoreServiceFactory]::CoreService.OnImportModule(
    "VMware.VimAutomation.Vds.Commands",
    $PSScriptRoot);
# Set any aliases here...